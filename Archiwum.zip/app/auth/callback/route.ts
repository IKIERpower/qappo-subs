import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const LOCALES = ['en', 'pl']

function getLocale(request: NextRequest): string {
    const cookie = request.cookies.get('NEXT_LOCALE')?.value
    if (cookie && LOCALES.includes(cookie)) return cookie
    const acceptLang = request.headers.get('accept-language') ?? ''
    const preferred = acceptLang.split(',')[0].split('-')[0].toLowerCase()
    return LOCALES.includes(preferred) ? preferred : 'pl'
}

export async function GET(request: NextRequest) {
    const { searchParams, origin } = new URL(request.url)
    const code = searchParams.get('code')
    const token_hash = searchParams.get('token_hash')
    const type = searchParams.get('type')
    const locale = getLocale(request)

    const cookieStore = await cookies()
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                getAll() { return cookieStore.getAll() },
                setAll(cookiesToSet) {
                    cookiesToSet.forEach(({ name, value, options }) =>
                        cookieStore.set(name, value, options)
                    )
                },
            },
        }
    )

    if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code)
        if (!error) {
            if (type === 'recovery') {
                const response = NextResponse.redirect(`${origin}/${locale}/auth/update-password`)
                response.cookies.set('auth_intent', 'recovery', { path: '/', maxAge: 300, httpOnly: true })
                return response
            }
            return NextResponse.redirect(`${origin}/${locale}/dashboard`)
        }
    }

    if (token_hash && type) {
        const { error } = await supabase.auth.verifyOtp({ token_hash, type: type as any })
        if (!error) {
            if (type === 'recovery') {
                const response = NextResponse.redirect(`${origin}/${locale}/auth/update-password`)
                response.cookies.set('auth_intent', 'recovery', { path: '/', maxAge: 300, httpOnly: true })
                return response
            }
            if (type === 'email_change') {
                return NextResponse.redirect(`${origin}/${locale}/settings`)
            }
            return NextResponse.redirect(`${origin}/${locale}/dashboard`)
        }
    }

    return NextResponse.redirect(`${origin}/${locale}/auth/login?error=callback_failed`)
}
