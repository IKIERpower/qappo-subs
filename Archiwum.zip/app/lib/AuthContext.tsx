'use client'

import { createContext, useContext, useEffect, useState, ReactNode, useRef, useMemo } from 'react'
import { Session, User } from '@supabase/supabase-js'
import { getSupabaseBrowserClient } from '@/app/lib/supabase'
const supabase = getSupabaseBrowserClient()
import { useRouter, usePathname } from 'next/navigation'
import { LOCALES } from '@/app/lib/LocaleContext'
import type { Locale } from '@/app/lib/LocaleContext'

interface AuthContextType {
    user: User | null
    session: Session | null
    loading: boolean
    displayName: string
    setDisplayName: (name: string) => Promise<void>
    signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
    user: null,
    session: null,
    loading: true,
    displayName: '',
    setDisplayName: async () => {},
    signOut: async () => {},
})

// Public paths that don't require auth - now locale-prefixed
const PUBLIC_PATH_SEGMENTS = ['', 'auth', 'legal']

function getLocaleFromPathname(pathname: string): Locale {
    const segment = pathname.split('/')[1]
    return LOCALES.includes(segment as Locale) ? (segment as Locale) : 'pl'
}

function isPublicPath(pathname: string): boolean {
    // Strip locale prefix: /pl/auth/login -> /auth/login
    const parts = pathname.split('/')
    const withoutLocale = LOCALES.includes(parts[1] as Locale)
        ? '/' + parts.slice(2).join('/')
        : pathname
    const firstSegment = withoutLocale.split('/')[1] ?? ''
    return PUBLIC_PATH_SEGMENTS.includes(firstSegment)
}

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null)
    const [session, setSession] = useState<Session | null>(null)
    const [loading, setLoading] = useState(true)
    const [initialized, setInitialized] = useState(false)
    const [displayName, setDisplayNameState] = useState('')
    const displayNameLoadedRef = useRef(false)
    const router = useRouter()
    const pathname = usePathname()

    useEffect(() => {
        let isMounted = true
        const initializeAuth = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession()
                if (isMounted) {
                    setSession(session)
                    setUser(session?.user ?? null)
                    setLoading(false)
                    setInitialized(true)
                }
            } catch {
                if (isMounted) {
                    setLoading(false)
                    setInitialized(true)
                }
            }
        }
        initializeAuth()

        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            if (isMounted) {
                setSession(session)
                setUser(session?.user ?? null)
            }
        })

        return () => {
            isMounted = false
            subscription.unsubscribe()
        }
    }, [])

    useEffect(() => {
        if (!user || displayNameLoadedRef.current) return
        displayNameLoadedRef.current = true
        let isMounted = true
        async function loadDisplayName() {
            try {
                const { data } = await supabase
                    .from('profiles')
                    .select('display_name')
                    .eq('id', user!.id)
                    .single()
                if (isMounted) {
                    setDisplayNameState(data?.display_name || user!.email?.split('@')[0] || '')
                }
            } catch {
                if (isMounted) setDisplayNameState(user!.email?.split('@')[0] || '')
            }
        }
        loadDisplayName()
        return () => { isMounted = false }
    }, [user?.id])

    useEffect(() => {
        if (!initialized || loading) return
        if (!user && !isPublicPath(pathname)) {
            const locale = getLocaleFromPathname(pathname)
            router.replace(`/${locale}/auth/login`)
        }
    }, [initialized, loading, user, pathname, router])

    async function setDisplayName(name: string) {
        if (!user) return
        try {
            await supabase.from('profiles').upsert({ id: user.id, display_name: name }, { onConflict: 'id' })
            setDisplayNameState(name)
        } catch (error) {
            console.error('Error saving display name:', error)
        }
    }

    async function signOut() {
        const locale = getLocaleFromPathname(pathname)
        await supabase.auth.signOut()
        setDisplayNameState('')
        displayNameLoadedRef.current = false
        router.replace(`/${locale}`)
    }

    const value = useMemo(
        () => ({ user, session, loading, displayName, setDisplayName, signOut }),
        [user, session, loading, displayName]
    )

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
    return useContext(AuthContext)
}
